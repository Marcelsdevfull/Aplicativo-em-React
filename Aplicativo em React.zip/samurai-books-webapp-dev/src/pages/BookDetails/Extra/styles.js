import styled from "styled-components";

export const Container = styled.div`
  font-size: 16px;
  margin-top: 25px;

  .title {
    font-weight: bold;
  }
`;
